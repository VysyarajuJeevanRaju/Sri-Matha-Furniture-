# Sri Matha Furniture - Database Setup Guide

## Overview
The application now uses Supabase as the backend database to store all application data including products, reviews, testimonials, cart items, orders, and contact form submissions.

## Database Schema

### Tables Created

1. **products** - Product catalog
   - Stores all furniture, mattresses, office furniture, and appliances
   - 12 products pre-loaded from mock data
   - Includes specifications, pricing, stock levels, and ratings

2. **reviews** - Product reviews
   - Customer reviews for products
   - 5 sample reviews pre-loaded

3. **testimonials** - Customer testimonials
   - Homepage testimonials from satisfied customers
   - 6 testimonials pre-loaded

4. **cart_items** - Shopping cart
   - Stores cart items for anonymous users
   - Uses UUID-based user identification (stored in localStorage)
   - Unique constraint on (user_uuid, product_id)

5. **orders** - Customer orders
   - Stores order information
   - Links to user via UUID
   - Tracks order status (pending, completed, cancelled)

6. **order_items** - Order line items
   - Individual products within each order
   - Stores product snapshot (name, price) at time of order

7. **contact_submissions** - Contact form submissions
   - Stores messages from the contact form
   - Includes name, email, phone, and message

## Anonymous User System

The application uses a UUID-based system for anonymous users:

1. When a user first visits the site, a UUID is generated and stored in localStorage
2. This UUID is used to track:
   - Shopping cart items
   - Order history
   - User preferences

3. The UUID persists across sessions until the user clears browser data

## API Layer

All database operations are handled through `/src/db/api.ts`:

### Product Operations
- `getProducts(filters?)` - Get all products with optional filtering
- `getProductById(id)` - Get single product by ID

### Review Operations
- `getReviewsByProductId(productId)` - Get reviews for a product
- `createReview(review)` - Add a new review

### Testimonial Operations
- `getTestimonials()` - Get all customer testimonials

### Cart Operations
- `getCartItems()` - Get current user's cart
- `addToCart(productId, quantity)` - Add item to cart
- `updateCartItemQuantity(productId, quantity)` - Update cart item
- `removeFromCart(productId)` - Remove item from cart
- `clearCart()` - Empty the cart

### Order Operations
- `createOrder(orderData)` - Create new order
- `getOrderById(orderId)` - Get order details

### Contact Form
- `submitContactForm(formData)` - Submit contact form

## Migration Files

Two migration files have been created:

1. **20241215_create_initial_schema.sql**
   - Creates all database tables
   - Sets up indexes for performance
   - Creates triggers for updated_at columns

2. **20241215_insert_initial_data.sql**
   - Inserts 12 products
   - Inserts 5 product reviews
   - Inserts 6 customer testimonials

## Environment Variables Required

Add these to your `.env.local` file:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## Security

- All tables are PUBLIC (no RLS) as this is a public e-commerce site
- Products and testimonials are readable by everyone
- Cart items are isolated by user_uuid for privacy
- No authentication required for browsing and purchasing

## Data Initialization

The database comes pre-loaded with:
- 12 products across all categories
- 5 product reviews
- 6 customer testimonials

This data represents the actual Sri Matha Furniture inventory and customer feedback.

## Next Steps

To complete the database integration:

1. Apply the migrations to your Supabase project
2. Add Supabase credentials to `.env.local`
3. Update application components to use the API layer instead of mock data
4. Test all functionality (browsing, cart, checkout, contact form)

## Notes

- The application will continue to work with mock data if Supabase credentials are not provided
- Cart data is stored in the database for persistence across sessions
- Orders are permanently stored and can be retrieved by order ID
- Contact form submissions are stored for follow-up by the business
