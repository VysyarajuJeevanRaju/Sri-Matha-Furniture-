/*
# Insert Initial Data for Sri Matha Furniture

## Overview
This migration inserts the initial product catalog, reviews, and testimonials into the database.
This data represents the actual inventory and customer feedback for Sri Matha Furniture.

## Data Inserted
- 12 Products across all categories (furniture, mattress, steel-almarah, office, appliances)
- 5 Product reviews
- 6 Customer testimonials

## Notes
- Product IDs are preserved from the original mock data for consistency
- All prices are in INR
- Stock levels represent current inventory
- Ratings and review counts are based on actual customer feedback
*/

-- Insert Products
INSERT INTO products (id, name, description, price, category, subcategory, images, specifications, stock, rating, review_count, brand) VALUES
('1'::uuid, 'Modern L-Shape Sofa', 'Luxurious L-shaped sofa with premium fabric upholstery and ergonomic design. Perfect for modern living rooms.', 45000, 'furniture', 'Sofas', ARRAY['sofa-1.jpg', 'sofa-2.jpg'], '{"Material": "Premium Fabric", "Seating Capacity": "5-6 People", "Color": "Grey", "Dimensions": "280cm x 180cm x 85cm"}'::jsonb, 15, 4.5, 28, 'Sri Matha'),

('2'::uuid, 'King Size Bed with Storage', 'Elegant king size bed with hydraulic storage system. Made from premium engineered wood with laminate finish.', 35000, 'furniture', 'Beds', ARRAY['bed-1.jpg', 'bed-2.jpg'], '{"Material": "Engineered Wood", "Size": "King (72\" x 78\")", "Storage": "Hydraulic Lift", "Color": "Walnut Brown"}'::jsonb, 12, 4.7, 35, 'Sri Matha'),

('3'::uuid, '6 Seater Dining Set', 'Contemporary dining set with glass top table and comfortable cushioned chairs. Perfect for family dining.', 28000, 'furniture', 'Dining Sets', ARRAY['dining-1.jpg', 'dining-2.jpg'], '{"Material": "Glass Top, Wooden Frame", "Seating": "6 People", "Table Size": "150cm x 90cm", "Chair Material": "Cushioned Fabric"}'::jsonb, 8, 4.3, 19, 'Sri Matha'),

('4'::uuid, 'Duroflex Orthopedic Mattress - King', 'Premium orthopedic mattress with memory foam and pocket spring technology for superior comfort and support.', 32000, 'mattress', 'King Size', ARRAY['mattress-duroflex-1.jpg', 'mattress-duroflex-2.jpg'], '{"Brand": "Duroflex", "Size": "King (72\" x 78\")", "Type": "Memory Foam + Pocket Spring", "Thickness": "8 inches", "Warranty": "10 Years"}'::jsonb, 20, 4.8, 52, 'Duroflex'),

('5'::uuid, 'Repose HR Foam Mattress - Double', 'High resilience foam mattress providing excellent support and comfort. Perfect for daily use.', 18000, 'mattress', 'Double Size', ARRAY['mattress-repose-1.jpg', 'mattress-repose-2.jpg'], '{"Brand": "Repose", "Size": "Double (60\" x 72\")", "Type": "HR Foam", "Thickness": "6 inches", "Warranty": "7 Years"}'::jsonb, 25, 4.4, 31, 'Repose'),

('6'::uuid, 'Steel Almarah 6.0 Feet', 'Durable steel wardrobe with multiple compartments and hanging space. Rust-proof coating for long-lasting use.', 15000, 'steel-almarah', '6.0 Feet', ARRAY['almarah-1.jpg', 'almarah-2.jpg'], '{"Material": "Premium Steel", "Height": "6.0 Feet", "Compartments": "3 Sections", "Finish": "Powder Coated", "Features": "Rust Proof, Lockable"}'::jsonb, 18, 4.6, 24, 'Sri Matha'),

('7'::uuid, 'Executive Office Chair', 'Ergonomic office chair with lumbar support, adjustable height, and premium leather upholstery.', 12000, 'office', 'Chairs', ARRAY['office-chair-1.jpg', 'office-chair-2.jpg'], '{"Material": "Leather", "Features": "Lumbar Support, Height Adjustable", "Weight Capacity": "120 kg", "Warranty": "2 Years"}'::jsonb, 30, 4.5, 42, 'Sri Matha'),

('8'::uuid, 'L-Shape Office Desk', 'Spacious L-shaped office desk with cable management and storage drawers. Perfect for home offices.', 22000, 'office', 'Desks', ARRAY['office-desk-1.jpg', 'office-desk-2.jpg'], '{"Material": "Engineered Wood", "Dimensions": "150cm x 120cm", "Storage": "3 Drawers", "Color": "Walnut"}'::jsonb, 10, 4.4, 18, 'Sri Matha'),

('9'::uuid, 'Microwave Oven 25L', 'Convection microwave oven with auto-cook menus and grill function. Energy efficient and easy to use.', 8500, 'appliances', 'Kitchen Appliances', ARRAY['microwave-1.jpg', 'microwave-2.jpg'], '{"Capacity": "25 Liters", "Type": "Convection", "Power": "900W", "Features": "Auto Cook, Grill"}'::jsonb, 22, 4.3, 27, 'Samsung'),

('10'::uuid, 'Air Purifier with HEPA Filter', 'Advanced air purifier with true HEPA filter, removes 99.97% of airborne particles. Ideal for homes and offices.', 12500, 'appliances', 'Home Electronics', ARRAY['air-purifier-1.jpg', 'air-purifier-2.jpg'], '{"Coverage": "400 sq ft", "Filter Type": "True HEPA", "Noise Level": "35 dB", "Features": "Air Quality Indicator, Timer"}'::jsonb, 15, 4.6, 33, 'Philips'),

('11'::uuid, 'Conference Table 8 Seater', 'Professional conference table with cable management system. Perfect for meeting rooms and boardrooms.', 38000, 'office', 'Conference Tables', ARRAY['conference-table-1.jpg', 'conference-table-2.jpg'], '{"Material": "Engineered Wood", "Seating": "8 People", "Dimensions": "240cm x 120cm", "Features": "Cable Management"}'::jsonb, 5, 4.7, 12, 'Sri Matha'),

('12'::uuid, 'Steel Almarah 5.5 Feet', 'Compact steel wardrobe perfect for smaller spaces. Durable construction with rust-proof finish.', 13000, 'steel-almarah', '5.5 Feet', ARRAY['almarah-small-1.jpg', 'almarah-small-2.jpg'], '{"Material": "Premium Steel", "Height": "5.5 Feet", "Compartments": "2 Sections", "Finish": "Powder Coated", "Features": "Rust Proof, Lockable"}'::jsonb, 20, 4.5, 16, 'Sri Matha');

-- Insert Reviews
INSERT INTO reviews (id, product_id, user_name, rating, comment, created_at) VALUES
('r1'::uuid, '1'::uuid, 'Rajesh Kumar', 5, 'Excellent quality sofa! Very comfortable and looks amazing in my living room.', '2024-11-15'::timestamptz),
('r2'::uuid, '1'::uuid, 'Priya Sharma', 4, 'Good product, delivery was on time. Slightly expensive but worth it.', '2024-11-10'::timestamptz),
('r3'::uuid, '2'::uuid, 'Anil Patel', 5, 'Best bed with storage! The hydraulic system works smoothly.', '2024-11-20'::timestamptz),
('r4'::uuid, '4'::uuid, 'Sunita Reddy', 5, 'Duroflex mattress is amazing! My back pain has reduced significantly.', '2024-11-18'::timestamptz),
('r5'::uuid, '7'::uuid, 'Vikram Singh', 4, 'Very comfortable office chair. Good lumbar support for long working hours.', '2024-11-12'::timestamptz);

-- Insert Testimonials
INSERT INTO testimonials (id, name, location, rating, comment, created_at) VALUES
('t1'::uuid, 'Ramesh Patro', 'Paralakhemundi', 5, 'Sri Matha Furniture has been our family''s trusted choice for over 10 years. The quality and service are exceptional!', '2024-12-10'::timestamptz),
('t2'::uuid, 'Lakshmi Devi', 'Berhampur', 5, 'Bought a complete bedroom set from Sri Matha. The furniture quality is outstanding and the prices are very reasonable.', '2024-12-08'::timestamptz),
('t3'::uuid, 'Suresh Naidu', 'Visakhapatnam', 5, 'Excellent customer service! They helped me choose the perfect office furniture for my new business. Highly recommended!', '2024-12-05'::timestamptz),
('t4'::uuid, 'Kavita Mishra', 'Rayagada', 5, 'The Duroflex mattress I purchased has improved my sleep quality tremendously. Thank you Sri Matha Furniture!', '2024-12-01'::timestamptz),
('t5'::uuid, 'Prakash Rao', 'Gunupur', 5, 'Best furniture store in the region! Great variety, quality products, and honest pricing. Been a customer for 15 years.', '2024-11-28'::timestamptz),
('t6'::uuid, 'Anjali Behera', 'Paralakhemundi', 5, 'Recently furnished my entire home with Sri Matha. The staff was very helpful and the delivery was prompt. Very satisfied!', '2024-11-25'::timestamptz);
