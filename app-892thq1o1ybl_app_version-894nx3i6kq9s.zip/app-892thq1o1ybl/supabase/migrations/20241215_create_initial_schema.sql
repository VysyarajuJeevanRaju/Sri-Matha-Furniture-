/*
# Sri Matha Furniture E-commerce Database Schema

## Overview
This migration creates the complete database schema for the Sri Matha Furniture e-commerce platform.
The system supports anonymous shopping with UUID-based user identification stored in localStorage.

## Tables Created

### 1. products
Stores all product information including furniture, mattresses, office furniture, and appliances.
- `id` (uuid, primary key): Unique product identifier
- `name` (text, not null): Product name
- `description` (text): Detailed product description
- `price` (numeric, not null): Product price in INR
- `category` (text, not null): Product category (furniture, appliances, office, mattress, steel-almarah)
- `subcategory` (text): Product subcategory
- `images` (text[]): Array of image URLs
- `specifications` (jsonb): Product specifications as key-value pairs
- `stock` (integer, default 0): Available stock quantity
- `rating` (numeric, default 0): Average product rating
- `review_count` (integer, default 0): Total number of reviews
- `brand` (text): Product brand name
- `created_at` (timestamptz): Record creation timestamp
- `updated_at` (timestamptz): Last update timestamp

### 2. reviews
Stores product reviews from customers.
- `id` (uuid, primary key): Unique review identifier
- `product_id` (uuid, foreign key): References products table
- `user_name` (text, not null): Reviewer name
- `rating` (integer, not null): Rating (1-5)
- `comment` (text): Review text
- `created_at` (timestamptz): Review creation date

### 3. testimonials
Stores customer testimonials displayed on the homepage.
- `id` (uuid, primary key): Unique testimonial identifier
- `name` (text, not null): Customer name
- `location` (text): Customer location
- `rating` (integer, not null): Rating (1-5)
- `comment` (text, not null): Testimonial text
- `created_at` (timestamptz): Testimonial date

### 4. cart_items
Stores shopping cart items for anonymous users (identified by UUID in localStorage).
- `id` (uuid, primary key): Unique cart item identifier
- `user_uuid` (uuid, not null): Anonymous user identifier from localStorage
- `product_id` (uuid, foreign key): References products table
- `quantity` (integer, not null): Item quantity
- `created_at` (timestamptz): When item was added to cart
- `updated_at` (timestamptz): Last update timestamp

### 5. orders
Stores customer orders.
- `id` (uuid, primary key): Unique order identifier
- `user_uuid` (uuid, not null): Anonymous user identifier
- `total_amount` (numeric, not null): Total order amount
- `status` (text, not null): Order status (pending, completed, cancelled)
- `customer_name` (text): Customer name
- `customer_email` (text): Customer email
- `customer_phone` (text): Customer phone
- `shipping_address` (text): Delivery address
- `created_at` (timestamptz): Order creation date
- `updated_at` (timestamptz): Last update timestamp

### 6. order_items
Stores individual items within each order.
- `id` (uuid, primary key): Unique order item identifier
- `order_id` (uuid, foreign key): References orders table
- `product_id` (uuid, foreign key): References products table
- `product_name` (text, not null): Product name snapshot
- `product_price` (numeric, not null): Product price snapshot
- `quantity` (integer, not null): Item quantity
- `subtotal` (numeric, not null): Line item subtotal

### 7. contact_submissions
Stores contact form submissions.
- `id` (uuid, primary key): Unique submission identifier
- `name` (text, not null): Sender name
- `email` (text, not null): Sender email
- `phone` (text): Sender phone
- `message` (text, not null): Message content
- `created_at` (timestamptz): Submission timestamp

## Security
- All tables are PUBLIC (no RLS enabled) as this is a public e-commerce site
- Anonymous users can browse products, add to cart, and place orders
- All data is publicly readable
- Cart items are isolated by user_uuid for privacy

## Indexes
- Created indexes on foreign keys for optimal query performance
- Index on user_uuid for cart and order lookups
- Index on product category for filtering

## Notes
- Uses UUID for all primary keys
- Timestamps use timestamptz for timezone awareness
- JSONB used for flexible product specifications
- Array type used for product images
*/

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price numeric NOT NULL CHECK (price >= 0),
  category text NOT NULL,
  subcategory text,
  images text[] DEFAULT '{}',
  specifications jsonb DEFAULT '{}',
  stock integer DEFAULT 0 CHECK (stock >= 0),
  rating numeric DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  review_count integer DEFAULT 0 CHECK (review_count >= 0),
  brand text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  user_name text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz DEFAULT now()
);

-- Create testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  location text,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create cart_items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_uuid uuid NOT NULL,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity integer NOT NULL CHECK (quantity > 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_uuid, product_id)
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_uuid uuid NOT NULL,
  total_amount numeric NOT NULL CHECK (total_amount >= 0),
  status text NOT NULL DEFAULT 'pending',
  customer_name text,
  customer_email text,
  customer_phone text,
  shipping_address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  product_name text NOT NULL,
  product_price numeric NOT NULL CHECK (product_price >= 0),
  quantity integer NOT NULL CHECK (quantity > 0),
  subtotal numeric NOT NULL CHECK (subtotal >= 0)
);

-- Create contact_submissions table
CREATE TABLE IF NOT EXISTS contact_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_reviews_product_id ON reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_user_uuid ON cart_items(user_uuid);
CREATE INDEX IF NOT EXISTS idx_cart_items_product_id ON cart_items(product_id);
CREATE INDEX IF NOT EXISTS idx_orders_user_uuid ON orders(user_uuid);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product_id ON order_items(product_id);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_cart_items_updated_at BEFORE UPDATE ON cart_items
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
