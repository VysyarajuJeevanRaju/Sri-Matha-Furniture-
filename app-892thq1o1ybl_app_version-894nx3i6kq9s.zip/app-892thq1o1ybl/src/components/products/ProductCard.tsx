import { Link } from 'react-router-dom';
import { Star, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Product } from '@/types/types';
import { cartStorage } from '@/lib/localStorage';
import { useToast } from '@/hooks/use-toast';

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { toast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    cartStorage.add({ product, quantity: 1 });
    window.dispatchEvent(new Event('cartUpdated'));
    toast({
      title: 'Added to cart',
      description: `${product.name} has been added to your cart.`
    });
  };

  return (
    <Link to={`/product/${product.id}`}>
      <Card className="holographic-card h-full overflow-hidden group">
        <div className="relative aspect-square overflow-hidden bg-muted">
          <img
            src={`https://placehold.co/400x400/0A1128/FF9900?text=${encodeURIComponent(product.name)}`}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
          />
          <Badge className="absolute top-2 left-2 bg-destructive text-destructive-foreground font-bold">
            NO RETURNABLE
          </Badge>
          {product.stock < 5 && product.stock > 0 && (
            <Badge className="absolute top-2 right-2 bg-destructive text-destructive-foreground">
              Only {product.stock} left
            </Badge>
          )}
          {product.stock === 0 && (
            <Badge className="absolute top-2 right-2 bg-destructive text-destructive-foreground">
              Out of Stock
            </Badge>
          )}
        </div>

        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-semibold text-lg line-clamp-2 group-hover:text-accent transition-colors">
              {product.name}
            </h3>
          </div>

          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
            {product.description}
          </p>

          <div className="flex items-center gap-1 mb-3">
            <Star className="h-4 w-4 fill-accent text-accent" />
            <span className="text-sm font-medium">{product.rating}</span>
            <span className="text-sm text-muted-foreground">({product.reviewCount})</span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-accent">₹{product.price.toLocaleString()}</span>
          </div>
        </CardContent>

        <CardFooter className="p-4 pt-0">
          <Button
            onClick={handleAddToCart}
            disabled={product.stock === 0}
            className="w-full neon-glow"
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            Add to Cart
          </Button>
        </CardFooter>
      </Card>
    </Link>
  );
};

export default ProductCard;
