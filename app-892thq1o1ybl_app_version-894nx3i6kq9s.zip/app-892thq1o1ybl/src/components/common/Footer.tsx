import { Link } from 'react-router-dom';
import { Phone, MapPin, Mail } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary border-t border-accent/20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img 
                src="/logo.jpg" 
                alt="Sri Matha Furniture Logo" 
                className="h-12 w-12 object-contain rounded-lg"
              />
              <span className="text-lg font-bold text-[#000000ff]">
                Sri Matha Furniture
              </span>
            </div>
            <p className="text-primary-foreground/80 text-sm">
              Serving customers across Odisha and Andhra Pradesh for the past 35 years with quality furniture, appliances, and office solutions.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-accent mb-4">Quick Links</h3>
            <div className="flex flex-col gap-2">
              <Link to="/" className="text-primary-foreground/80 hover:text-accent transition-colors">
                Home
              </Link>
              <Link to="/products" className="text-primary-foreground/80 hover:text-accent transition-colors">Products</Link>
              <Link to="/about" className="text-primary-foreground/80 hover:text-accent transition-colors">
                About Us
              </Link>
              <Link to="/contact" className="text-primary-foreground/80 hover:text-accent transition-colors">
                Contact
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-accent mb-4">Categories</h3>
            <div className="flex flex-col gap-2">
              <Link to="/products?category=furniture" className="text-primary-foreground/80 hover:text-accent transition-colors">
                Furniture
              </Link>
              <Link to="/products?category=mattress" className="text-primary-foreground/80 hover:text-accent transition-colors">
                Mattress
              </Link>
              <Link to="/products?category=office" className="text-primary-foreground/80 hover:text-accent transition-colors">
                Office Furniture
              </Link>
              <Link to="/products?category=appliances" className="text-primary-foreground/80 hover:text-accent transition-colors">
                Appliances
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-accent mb-4">Contact Us</h3>
            <div className="flex flex-col gap-3">
              <div className="flex items-start gap-2">
                <MapPin className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
                <span className="text-primary-foreground/80 text-sm">
                  Paralakhemundi, Gajapathi Dist. Odisha
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-accent flex-shrink-0" />
                <div className="flex flex-col">
                  <a href="tel:8074956624" className="text-primary-foreground/80 hover:text-accent transition-colors text-sm">
                    8074956624
                  </a>
                  <a href="tel:7995344540" className="text-primary-foreground/80 hover:text-accent transition-colors text-sm">
                    7995344540
                  </a>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-accent flex-shrink-0" />
                <a href="mailto:Srimathafurniture@gmail.com" className="text-primary-foreground/80 hover:text-accent transition-colors text-sm">
                  Srimathafurniture@gmail.com
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-accent/20 text-center">
          <p className="text-primary-foreground/60 text-sm">2025 Sri Matha Furniture powered by Jeevan</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
