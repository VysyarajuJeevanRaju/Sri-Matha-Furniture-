import { useLocation, Link } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const OrderSuccess = () => {
  const location = useLocation();
  const orderId = location.state?.orderId;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        <Card className="holographic-card">
          <CardContent className="p-8 text-center">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-accent/20 flex items-center justify-center neon-glow">
              <CheckCircle2 className="h-12 w-12 text-accent" />
            </div>

            <h1 className="text-3xl font-bold mb-4">
              Order Placed <span className="gradient-text">Successfully!</span>
            </h1>

            <p className="text-muted-foreground mb-6">
              Thank you for your order. We have received your order and will contact you soon to confirm the details.
            </p>

            {orderId && (
              <div className="bg-muted/50 rounded-lg p-4 mb-6">
                <p className="text-sm text-muted-foreground mb-1">Order ID</p>
                <p className="text-lg font-mono font-bold">{orderId}</p>
              </div>
            )}

            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                A confirmation email has been sent to your email address with order details.
              </p>

              <div className="flex flex-col xl:flex-row gap-4 justify-center">
                <Link to="/products">
                  <Button className="neon-glow w-full xl:w-auto">
                    Continue Shopping
                  </Button>
                </Link>
                <Link to="/">
                  <Button variant="outline" className="neon-border w-full xl:w-auto">
                    Back to Home
                  </Button>
                </Link>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-border">
              <h3 className="font-semibold mb-3">What happens next?</h3>
              <div className="text-left space-y-2 text-sm text-muted-foreground">
                <p>✓ Our team will review your order</p>
                <p>✓ We will contact you to confirm delivery details</p>
                <p>✓ Your order will be prepared for delivery</p>
                <p>✓ You will receive updates via phone and email</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default OrderSuccess;
