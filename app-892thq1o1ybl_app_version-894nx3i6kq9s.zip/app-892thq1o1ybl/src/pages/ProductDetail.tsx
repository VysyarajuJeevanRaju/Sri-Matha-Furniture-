import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Star, ShoppingCart, Minus, Plus, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { products, reviews as mockReviews } from '@/lib/mockData';
import { cartStorage, reviewStorage } from '@/lib/localStorage';
import { useToast } from '@/hooks/use-toast';
import ProductCard from '@/components/products/ProductCard';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState<string>('');

  const product = products.find(p => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Product not found</h2>
          <Link to="/products">
            <Button>Back to Products</Button>
          </Link>
        </div>
      </div>
    );
  }

  const productReviews = [...mockReviews.filter(r => r.productId === id), ...reviewStorage.getByProductId(id)];
  const relatedProducts = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  // Determine if product needs size selection
  const needsSizeSelection = product.category === 'mattress' || product.category === 'steel-almarah';
  
  // Get available sizes based on category
  const getAvailableSizes = () => {
    if (product.category === 'mattress') {
      return ['Single (36" x 72")', 'Double (48" x 72")', 'Queen (60" x 78")', 'King (72" x 78")'];
    } else if (product.category === 'steel-almarah') {
      return ['4.5 Feet', '5.0 Feet', '5.5 Feet', '6.0 Feet', '6.5 Feet'];
    }
    return [];
  };

  const availableSizes = getAvailableSizes();

  const handleAddToCart = () => {
    if (needsSizeSelection && !selectedSize) {
      toast({
        title: 'Size Required',
        description: 'Please select a size before adding to cart.',
        variant: 'destructive'
      });
      return;
    }
    
    cartStorage.add({ product, quantity });
    window.dispatchEvent(new Event('cartUpdated'));
    toast({
      title: 'Added to cart',
      description: `${quantity} x ${product.name}${selectedSize ? ` (${selectedSize})` : ''} added to your cart.`
    });
  };

  const handleBuyNow = () => {
    if (needsSizeSelection && !selectedSize) {
      toast({
        title: 'Size Required',
        description: 'Please select a size before proceeding.',
        variant: 'destructive'
      });
      return;
    }
    
    cartStorage.add({ product, quantity });
    window.dispatchEvent(new Event('cartUpdated'));
    navigate('/cart');
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-12">
          <div className="holographic-card overflow-hidden relative">
            <div className="aspect-square bg-muted">
              <img
                src={`https://placehold.co/800x800/0A1128/FF9900?text=${encodeURIComponent(product.name)}`}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <Badge className="absolute top-4 left-4 bg-destructive text-destructive-foreground font-bold text-sm">
              NO RETURNABLE
            </Badge>
          </div>

          <div>
            <div className="mb-4">
              <Badge className="mb-2">{product.category}</Badge>
              <h1 className="text-3xl xl:text-4xl font-bold mb-2">{product.name}</h1>
              {product.brand && (
                <p className="text-muted-foreground">Brand: {product.brand}</p>
              )}
            </div>

            <div className="flex items-center gap-2 mb-4">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(product.rating)
                        ? 'fill-accent text-accent'
                        : 'text-muted'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm font-medium">{product.rating}</span>
              <span className="text-sm text-muted-foreground">
                ({product.reviewCount} reviews)
              </span>
            </div>

            <div className="mb-6">
              <div className="text-4xl font-bold text-accent mb-2">
                ₹{product.price.toLocaleString()}
              </div>
              {product.stock > 0 ? (
                <Badge variant="outline" className="text-accent border-accent">
                  In Stock ({product.stock} available)
                </Badge>
              ) : (
                <Badge variant="destructive">Out of Stock</Badge>
              )}
            </div>

            <Separator className="my-6" />

            <div className="mb-6">
              <h3 className="font-semibold mb-2">Description</h3>
              <p className="text-muted-foreground">{product.description}</p>
            </div>

            {product.specifications && (
              <>
                <Separator className="my-6" />
                <div className="mb-6">
                  <h3 className="font-semibold mb-3">Specifications</h3>
                  <div className="grid grid-cols-1 gap-2">
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <div key={key} className="flex justify-between py-2 border-b border-border">
                        <span className="text-muted-foreground">{key}</span>
                        <span className="font-medium">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            <Separator className="my-6" />

            {needsSizeSelection && availableSizes.length > 0 && (
              <>
                <div className="mb-6">
                  <h3 className="font-semibold mb-3">Select Size</h3>
                  <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
                    {availableSizes.map((size) => (
                      <Button
                        key={size}
                        variant={selectedSize === size ? 'default' : 'outline'}
                        className={`h-auto py-3 ${selectedSize === size ? 'neon-glow' : ''}`}
                        onClick={() => setSelectedSize(size)}
                      >
                        {size}
                      </Button>
                    ))}
                  </div>
                </div>
                <Separator className="my-6" />
              </>
            )}

            <div className="mb-6">
              <h3 className="font-semibold mb-3">Quantity</h3>
              <div className="flex items-center gap-4">
                <div className="flex items-center border border-border rounded-lg">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="px-6 font-medium">{quantity}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                    disabled={quantity >= product.stock}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex flex-col xl:flex-row gap-4">
              <Button
                onClick={handleAddToCart}
                disabled={product.stock === 0}
                variant="outline"
                className="flex-1 neon-border"
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                Add to Cart
              </Button>
              <Button
                onClick={handleBuyNow}
                disabled={product.stock === 0}
                className="flex-1 neon-glow"
              >
                Buy Now
              </Button>
            </div>
          </div>
        </div>

        {productReviews.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6">Customer Reviews</h2>
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              {productReviews.map((review) => (
                <Card key={review.id} className="holographic-card">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className="font-semibold">{review.userName}</p>
                        <p className="text-sm text-muted-foreground">{review.date}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < review.rating ? 'fill-accent text-accent' : 'text-muted'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-muted-foreground">{review.comment}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Related Products</h2>
            <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
              {relatedProducts.map((relatedProduct) => (
                <ProductCard key={relatedProduct.id} product={relatedProduct} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
