import { Link } from 'react-router-dom';
import { ArrowRight, Sofa, Bed, Briefcase, Zap, Star, Quote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import ProductCard from '@/components/products/ProductCard';
import { products, customerTestimonials } from '@/lib/mockData';

const Home = () => {
  const featuredProducts = products.slice(0, 4);

  const categories = [
    {
      name: 'Furniture',
      icon: Sofa,
      description: 'Sofas, Beds, Dining Sets',
      link: '/products?category=furniture'
    },
    {
      name: 'Wood Furniture',
      icon: Sofa,
      description: 'Bookshelves, TV Units, Wardrobes',
      link: '/products?category=wood-furniture'
    },
    {
      name: 'Plastic Furniture',
      icon: Sofa,
      description: 'Chairs, Tables, Storage',
      link: '/products?category=plastic-furniture'
    },
    {
      name: 'Mattress',
      icon: Bed,
      description: 'Duroflex, Repose Brands',
      link: '/products?category=mattress'
    },
    {
      name: 'Steel Almarah',
      icon: Briefcase,
      description: '4.5 to 6.5 Feet Sizes',
      link: '/products?category=steel-almarah'
    },
    {
      name: 'Office Furniture',
      icon: Briefcase,
      description: 'Desks, Chairs, Tables',
      link: '/products?category=office'
    },
    {
      name: 'Appliances',
      icon: Zap,
      description: 'Fans, Mixer Grinders, Kitchen',
      link: '/products?category=appliances'
    }
  ];

  return (
    <div className="min-h-screen">
      <section className="relative py-20 xl:py-32 overflow-hidden bg-gradient-background">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-accent rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary-glow rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl xl:text-6xl font-bold mb-6 text-foreground font-['Helvetica Neue']">Sri Matha Furniture</h1>
            <p className="text-lg xl:text-xl mb-8 text-[#ffffffff]">
              Serving Odisha and Andhra Pradesh for 35 years with premium furniture, mattresses, and appliances. Experience the future of shopping today.
            </p>
            <div className="flex flex-col xl:flex-row gap-4 justify-center">
              <Link to="/products">
                <Button size="lg" className="neon-glow w-full xl:w-auto">
                  Explore Products
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/contact">
                <Button size="lg" variant="outline" className="neon-border w-full xl:w-auto">Contact Us</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl xl:text-4xl font-bold text-center mb-12">
            Shop by <span className="gradient-text">Category</span>
          </h2>

          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {categories.map((category) => (
              <Link key={category.name} to={category.link}>
                <Card className="holographic-card h-full">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-primary flex items-center justify-center neon-glow">
                      <category.icon className="h-8 w-8 text-primary-foreground" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">{category.name}</h3>
                    <p className="text-muted-foreground">{category.description}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl xl:text-4xl font-bold">
              Featured <span className="gradient-text">Products</span>
            </h2>
            <Link to="/products">
              <Button variant="outline" className="neon-border">
                View All
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>
      <section className="py-16 bg-gradient-background">
        <div className="container mx-auto px-4 bg-background">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl xl:text-4xl font-bold mb-6 text-[#ffffffff] font-['Helvetica Neue']">Why Choose Sri Matha Furniture?</h2>
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mt-12">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-accent/20 flex items-center justify-center neon-glow">
                  <span className="text-3xl font-bold text-accent">35+</span>
                </div>
                <h3 className="text-xl font-bold mb-2 text-[#ffffffff]">Years of Experience</h3>
                <p className="text-primary-foreground/70">Trusted by thousands of customers</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-accent/20 flex items-center justify-center neon-glow">
                  <span className="text-3xl font-bold text-accent">✓</span>
                </div>
                <h3 className="text-xl font-bold mb-2 text-[#ffffffff]">Quality Products</h3>
                <p className="text-primary-foreground/70">Premium brands and materials</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-accent/20 flex items-center justify-center neon-glow">
                  <span className="text-3xl font-bold text-accent">⚡</span>
                </div>
                <h3 className="text-xl font-bold mb-2 text-[#ffffffff]">Fast Delivery</h3>
                <p className="text-primary-foreground/70">Across Odisha and Andhra Pradesh</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl xl:text-4xl font-bold text-center mb-4 text-foreground">
            What Our <span className="text-accent">Customers Say</span>
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Trusted by thousands of satisfied customers across Odisha and Andhra Pradesh
          </p>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {customerTestimonials.slice(0, 6).map((testimonial) => (
              <Card key={testimonial.id} className="holographic-card">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-primary flex items-center justify-center flex-shrink-0">
                      <Quote className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-foreground">{testimonial.name}</h4>
                      <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                    </div>
                  </div>
                  <div className="flex gap-1 mb-3">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-accent text-accent" />
                    ))}
                  </div>
                  <p className="text-foreground/80 text-sm leading-relaxed">
                    {testimonial.comment}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
