import { Award, Users, TrendingUp, Heart } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const About = () => {
  const values = [
    {
      icon: Award,
      title: 'Quality First',
      description: 'We source only the finest materials and work with trusted brands to ensure lasting quality.'
    },
    {
      icon: Users,
      title: 'Customer Focused',
      description: 'Your satisfaction is our priority. We provide personalized service and support.'
    },
    {
      icon: TrendingUp,
      title: 'Innovation',
      description: 'Embracing modern technology while maintaining traditional values of craftsmanship.'
    },
    {
      icon: Heart,
      title: 'Trust & Integrity',
      description: '35 years of honest business practices and transparent dealings with our customers.'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <section className="bg-gradient-background py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="xl:text-5xl font-bold mb-6 text-[#ffffffff] border-solid border-[0px] border-[#482003ff] text-[24px]">About Sri Matha Furniture</h1>
          <p className="text-lg max-w-3xl mx-auto text-[#ffffffff]">
            Serving Odisha and Andhra Pradesh with quality furniture and appliances for over three decades
          </p>
        </div>
      </section>
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-3xl font-bold mb-6">
                Our <span className="gradient-text">Story</span>
              </h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Founded 35 years ago in Paralakhemundi, Gajapathi District, Odisha, Sri Matha Furniture began with a simple vision: to provide quality furniture and home solutions to families across the region.
                </p>
                <p>
                  Over the decades, we have grown from a small local shop to a trusted name serving customers across Odisha and Andhra Pradesh. Our commitment to quality, customer service, and fair pricing has remained unchanged.
                </p>
                <p>
                  Today, we offer an extensive range of furniture, premium mattresses from brands like Duroflex and Repose, office furniture, and home appliances. Our showroom showcases the latest designs while our experienced team helps customers find the perfect solutions for their homes and offices.
                </p>
              </div>
            </div>

            <div className="holographic-card aspect-video bg-muted rounded-lg overflow-hidden">
              <img
                src="https://placehold.co/800x600/0A1128/FF9900?text=Sri+Matha+Furniture+Store"
                alt="Sri Matha Furniture Store"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-12">
              Our <span className="gradient-text">Values</span>
            </h2>
            <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
              {values.map((value) => (
                <Card key={value.title} className="holographic-card">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-primary flex items-center justify-center neon-glow">
                      <value.icon className="h-8 w-8 text-primary-foreground" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                    <p className="text-muted-foreground text-sm">{value.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="bg-gradient-background rounded-lg p-8 xl:p-12 text-center">
            <h2 className="text-3xl font-bold mb-8 text-[#ffffffff]">Why Choose Us?</h2>
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              <div>
                <div className="text-4xl font-bold text-accent mb-2">35+</div>
                <p className="text-[#ffffffff]">Years of Experience</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-accent mb-2">10,000+</div>
                <p className="text-[#ffffffff]">Happy Customers</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-accent mb-2">500+</div>
                <p className="text-[#ffffffff]">Products Available</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
