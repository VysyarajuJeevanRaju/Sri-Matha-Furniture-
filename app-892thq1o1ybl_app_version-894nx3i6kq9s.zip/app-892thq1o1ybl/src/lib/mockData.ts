import type { Product, Review } from '@/types/types';

export const products: Product[] = [
  // Furniture - Sofas
  {
    id: '1',
    name: 'Modern L-Shape Sofa',
    description: 'Luxurious L-shaped sofa with premium fabric upholstery and ergonomic design. Perfect for modern living rooms.',
    price: 45000,
    category: 'furniture',
    subcategory: 'Sofas',
    images: ['sofa-1.jpg', 'sofa-2.jpg'],
    specifications: {
      'Material': 'Premium Fabric',
      'Seating Capacity': '5-6 People',
      'Color': 'Grey',
      'Dimensions': '280cm x 180cm x 85cm'
    },
    stock: 15,
    rating: 4.5,
    reviewCount: 28,
    brand: 'Sri Matha'
  },
  // Furniture - Beds
  {
    id: '2',
    name: 'King Size Bed with Storage',
    description: 'Elegant king size bed with hydraulic storage system. Made from premium engineered wood with laminate finish.',
    price: 35000,
    category: 'furniture',
    subcategory: 'Beds',
    images: ['bed-1.jpg', 'bed-2.jpg'],
    specifications: {
      'Material': 'Engineered Wood',
      'Size': 'King (72" x 78")',
      'Storage': 'Hydraulic Lift',
      'Color': 'Walnut Brown'
    },
    stock: 12,
    rating: 4.7,
    reviewCount: 35,
    brand: 'Sri Matha'
  },
  // Furniture - Dining Sets
  {
    id: '3',
    name: '6 Seater Dining Set',
    description: 'Contemporary dining set with glass top table and comfortable cushioned chairs. Perfect for family dining.',
    price: 28000,
    category: 'furniture',
    subcategory: 'Dining Sets',
    images: ['dining-1.jpg', 'dining-2.jpg'],
    specifications: {
      'Material': 'Glass Top, Wooden Frame',
      'Seating': '6 People',
      'Table Size': '150cm x 90cm',
      'Chair Material': 'Cushioned Fabric'
    },
    stock: 8,
    rating: 4.3,
    reviewCount: 19,
    brand: 'Sri Matha'
  },
  
  // Mattresses - Duroflex Brand
  {
    id: '4',
    name: 'Duroflex Orthopedic Mattress',
    description: 'Premium orthopedic mattress with memory foam and pocket spring technology for superior comfort and support.',
    price: 32000,
    category: 'mattress',
    subcategory: 'Memory Foam + Pocket Spring',
    images: ['mattress-duroflex-1.jpg', 'mattress-duroflex-2.jpg'],
    specifications: {
      'Brand': 'Duroflex',
      'Available Sizes': 'Single, Double, King, Queen',
      'Type': 'Memory Foam + Pocket Spring',
      'Thickness': '8 inches',
      'Warranty': '10 Years'
    },
    stock: 20,
    rating: 4.8,
    reviewCount: 52,
    brand: 'Duroflex'
  },
  {
    id: '5',
    name: 'Duroflex SuperSoft Mattress',
    description: 'Ultra-soft mattress with SuperSoft foam technology. Perfect for those who prefer plush comfort.',
    price: 28000,
    category: 'mattress',
    subcategory: 'SuperSoft Foam',
    images: ['mattress-duroflex-soft.jpg'],
    specifications: {
      'Brand': 'Duroflex',
      'Available Sizes': 'Single, Double, King, Queen',
      'Type': 'SuperSoft Foam',
      'Thickness': '6 inches',
      'Warranty': '8 Years'
    },
    stock: 18,
    rating: 4.6,
    reviewCount: 38,
    brand: 'Duroflex'
  },
  {
    id: '6',
    name: 'Duroflex Latex Mattress',
    description: 'Natural latex mattress with excellent breathability and durability. Hypoallergenic and eco-friendly.',
    price: 38000,
    category: 'mattress',
    subcategory: 'Latex',
    images: ['mattress-duroflex-latex.jpg'],
    specifications: {
      'Brand': 'Duroflex',
      'Available Sizes': 'Single, Double, King, Queen',
      'Type': 'Natural Latex',
      'Thickness': '8 inches',
      'Warranty': '12 Years'
    },
    stock: 12,
    rating: 4.9,
    reviewCount: 45,
    brand: 'Duroflex'
  },
  
  // Mattresses - Repose Brand
  {
    id: '7',
    name: 'Repose HR Foam Mattress',
    description: 'High resilience foam mattress providing excellent support and comfort. Perfect for daily use.',
    price: 18000,
    category: 'mattress',
    subcategory: 'HR Foam',
    images: ['mattress-repose-1.jpg', 'mattress-repose-2.jpg'],
    specifications: {
      'Brand': 'Repose',
      'Available Sizes': 'Single, Double, King, Queen',
      'Type': 'HR Foam',
      'Thickness': '6 inches',
      'Warranty': '7 Years'
    },
    stock: 25,
    rating: 4.4,
    reviewCount: 31,
    brand: 'Repose'
  },
  {
    id: '8',
    name: 'Repose PU Foam Mattress',
    description: 'Premium polyurethane foam mattress with excellent support and durability. Great value for money.',
    price: 15000,
    category: 'mattress',
    subcategory: 'PU Foam',
    images: ['mattress-repose-pu.jpg'],
    specifications: {
      'Brand': 'Repose',
      'Available Sizes': 'Single, Double, King, Queen',
      'Type': 'PU Foam',
      'Thickness': '5 inches',
      'Warranty': '5 Years'
    },
    stock: 30,
    rating: 4.3,
    reviewCount: 28,
    brand: 'Repose'
  },
  {
    id: '9',
    name: 'Repose Bonnel Spring Mattress',
    description: 'Traditional bonnel spring mattress with firm support. Ideal for those who prefer a firmer sleeping surface.',
    price: 22000,
    category: 'mattress',
    subcategory: 'Bonnel Spring',
    images: ['mattress-repose-spring.jpg'],
    specifications: {
      'Brand': 'Repose',
      'Available Sizes': 'Single, Double, King, Queen',
      'Type': 'Bonnel Spring',
      'Thickness': '7 inches',
      'Warranty': '8 Years'
    },
    stock: 20,
    rating: 4.5,
    reviewCount: 34,
    brand: 'Repose'
  },
  
  // Steel Almarah - All Sizes
  {
    id: '10',
    name: 'Steel Almarah 4.5 Feet',
    description: 'Compact steel wardrobe perfect for small spaces. Durable construction with rust-proof finish.',
    price: 10000,
    category: 'steel-almarah',
    subcategory: '4.5 Feet',
    images: ['almarah-45.jpg'],
    specifications: {
      'Material': 'Premium Steel',
      'Height': '4.5 Feet',
      'Compartments': '2 Sections',
      'Finish': 'Powder Coated',
      'Features': 'Rust Proof, Lockable'
    },
    stock: 25,
    rating: 4.4,
    reviewCount: 18,
    brand: 'Sri Matha'
  },
  {
    id: '11',
    name: 'Steel Almarah 5.0 Feet',
    description: 'Medium-sized steel wardrobe with ample storage space. Perfect for bedrooms.',
    price: 12000,
    category: 'steel-almarah',
    subcategory: '5.0 Feet',
    images: ['almarah-50.jpg'],
    specifications: {
      'Material': 'Premium Steel',
      'Height': '5.0 Feet',
      'Compartments': '2 Sections',
      'Finish': 'Powder Coated',
      'Features': 'Rust Proof, Lockable'
    },
    stock: 22,
    rating: 4.5,
    reviewCount: 20,
    brand: 'Sri Matha'
  },
  {
    id: '12',
    name: 'Steel Almarah 5.5 Feet',
    description: 'Spacious steel wardrobe with multiple compartments. Ideal for storing clothes and accessories.',
    price: 13000,
    category: 'steel-almarah',
    subcategory: '5.5 Feet',
    images: ['almarah-small-1.jpg', 'almarah-small-2.jpg'],
    specifications: {
      'Material': 'Premium Steel',
      'Height': '5.5 Feet',
      'Compartments': '2 Sections',
      'Finish': 'Powder Coated',
      'Features': 'Rust Proof, Lockable'
    },
    stock: 20,
    rating: 4.5,
    reviewCount: 16,
    brand: 'Sri Matha'
  },
  {
    id: '13',
    name: 'Steel Almarah 6.0 Feet',
    description: 'Large steel wardrobe with multiple compartments and hanging space. Rust-proof coating for long-lasting use.',
    price: 15000,
    category: 'steel-almarah',
    subcategory: '6.0 Feet',
    images: ['almarah-1.jpg', 'almarah-2.jpg'],
    specifications: {
      'Material': 'Premium Steel',
      'Height': '6.0 Feet',
      'Compartments': '3 Sections',
      'Finish': 'Powder Coated',
      'Features': 'Rust Proof, Lockable'
    },
    stock: 18,
    rating: 4.6,
    reviewCount: 24,
    brand: 'Sri Matha'
  },
  {
    id: '14',
    name: 'Steel Almarah 6.5 Feet',
    description: 'Extra-large steel wardrobe with maximum storage capacity. Perfect for large families.',
    price: 17000,
    category: 'steel-almarah',
    subcategory: '6.5 Feet',
    images: ['almarah-65.jpg'],
    specifications: {
      'Material': 'Premium Steel',
      'Height': '6.5 Feet',
      'Compartments': '3 Sections',
      'Finish': 'Powder Coated',
      'Features': 'Rust Proof, Lockable'
    },
    stock: 15,
    rating: 4.7,
    reviewCount: 22,
    brand: 'Sri Matha'
  },
  
  // Office Furniture
  {
    id: '15',
    name: 'Executive Office Chair',
    description: 'Ergonomic office chair with lumbar support, adjustable height, and premium leather upholstery.',
    price: 12000,
    category: 'office',
    subcategory: 'Chairs',
    images: ['office-chair-1.jpg', 'office-chair-2.jpg'],
    specifications: {
      'Material': 'Leather',
      'Features': 'Lumbar Support, Height Adjustable',
      'Weight Capacity': '120 kg',
      'Warranty': '2 Years'
    },
    stock: 30,
    rating: 4.5,
    reviewCount: 42,
    brand: 'Sri Matha'
  },
  {
    id: '16',
    name: 'L-Shape Office Desk',
    description: 'Spacious L-shaped office desk with cable management and storage drawers. Perfect for home offices.',
    price: 22000,
    category: 'office',
    subcategory: 'Desks',
    images: ['office-desk-1.jpg', 'office-desk-2.jpg'],
    specifications: {
      'Material': 'Engineered Wood',
      'Dimensions': '150cm x 120cm',
      'Storage': '3 Drawers',
      'Color': 'Walnut'
    },
    stock: 10,
    rating: 4.4,
    reviewCount: 18,
    brand: 'Sri Matha'
  },
  {
    id: '17',
    name: 'Conference Table 8 Seater',
    description: 'Professional conference table with cable management system. Perfect for meeting rooms and boardrooms.',
    price: 38000,
    category: 'office',
    subcategory: 'Conference Tables',
    images: ['conference-table-1.jpg', 'conference-table-2.jpg'],
    specifications: {
      'Material': 'Engineered Wood',
      'Seating': '8 People',
      'Dimensions': '240cm x 120cm',
      'Features': 'Cable Management'
    },
    stock: 5,
    rating: 4.7,
    reviewCount: 12,
    brand: 'Sri Matha'
  },
  
  // Appliances - Mixer Grinders
  {
    id: '18',
    name: 'Preethi Mixer Grinder 750W',
    description: 'Powerful 750W mixer grinder with 3 jars. Perfect for grinding, mixing, and blending.',
    price: 5500,
    category: 'appliances',
    subcategory: 'Mixer Grinders',
    images: ['mixer-preethi.jpg'],
    specifications: {
      'Power': '750W',
      'Jars': '3 (Liquidizing, Dry Grinding, Chutney)',
      'Speed Settings': '3 Speed + Pulse',
      'Warranty': '2 Years'
    },
    stock: 35,
    rating: 4.6,
    reviewCount: 48,
    brand: 'Preethi'
  },
  {
    id: '19',
    name: 'Philips Mixer Grinder 500W',
    description: 'Compact and efficient mixer grinder with 3 stainless steel jars. Easy to clean and maintain.',
    price: 4200,
    category: 'appliances',
    subcategory: 'Mixer Grinders',
    images: ['mixer-philips.jpg'],
    specifications: {
      'Power': '500W',
      'Jars': '3 Stainless Steel Jars',
      'Speed Settings': '3 Speed',
      'Warranty': '2 Years'
    },
    stock: 40,
    rating: 4.5,
    reviewCount: 52,
    brand: 'Philips'
  },
  
  // Appliances - Fans
  {
    id: '20',
    name: 'Crompton Ceiling Fan 1200mm',
    description: 'Energy-efficient ceiling fan with high air delivery. Perfect for large rooms.',
    price: 2800,
    category: 'appliances',
    subcategory: 'Fans',
    images: ['fan-ceiling-crompton.jpg'],
    specifications: {
      'Size': '1200mm (48 inches)',
      'Speed': '3 Speed Settings',
      'Air Delivery': '230 CMM',
      'Warranty': '2 Years'
    },
    stock: 50,
    rating: 4.4,
    reviewCount: 65,
    brand: 'Crompton'
  },
  {
    id: '21',
    name: 'Usha Table Fan 400mm',
    description: 'Powerful table fan with oscillation feature. Ideal for personal cooling.',
    price: 1800,
    category: 'appliances',
    subcategory: 'Fans',
    images: ['fan-table-usha.jpg'],
    specifications: {
      'Size': '400mm (16 inches)',
      'Speed': '3 Speed Settings',
      'Features': 'Oscillation, Tilt Adjustment',
      'Warranty': '2 Years'
    },
    stock: 45,
    rating: 4.3,
    reviewCount: 38,
    brand: 'Usha'
  },
  {
    id: '22',
    name: 'Havells Pedestal Fan 450mm',
    description: 'Adjustable height pedestal fan with powerful air throw. Perfect for large spaces.',
    price: 3200,
    category: 'appliances',
    subcategory: 'Fans',
    images: ['fan-pedestal-havells.jpg'],
    specifications: {
      'Size': '450mm (18 inches)',
      'Speed': '3 Speed Settings',
      'Features': 'Height Adjustable, Oscillation',
      'Warranty': '2 Years'
    },
    stock: 30,
    rating: 4.5,
    reviewCount: 42,
    brand: 'Havells'
  },
  
  // Appliances - Small Appliances
  {
    id: '23',
    name: 'Microwave Oven 25L',
    description: 'Convection microwave oven with auto-cook menus and grill function. Energy efficient and easy to use.',
    price: 8500,
    category: 'appliances',
    subcategory: 'Kitchen Appliances',
    images: ['microwave-1.jpg', 'microwave-2.jpg'],
    specifications: {
      'Capacity': '25 Liters',
      'Type': 'Convection',
      'Power': '900W',
      'Features': 'Auto Cook, Grill'
    },
    stock: 22,
    rating: 4.3,
    reviewCount: 27,
    brand: 'Samsung'
  },
  {
    id: '24',
    name: 'Electric Kettle 1.8L',
    description: 'Fast boiling electric kettle with auto shut-off feature. Perfect for tea and coffee.',
    price: 1200,
    category: 'appliances',
    subcategory: 'Small Appliances',
    images: ['kettle-electric.jpg'],
    specifications: {
      'Capacity': '1.8 Liters',
      'Power': '1500W',
      'Features': 'Auto Shut-off, Boil Dry Protection',
      'Warranty': '1 Year'
    },
    stock: 60,
    rating: 4.4,
    reviewCount: 55,
    brand: 'Prestige'
  },
  {
    id: '25',
    name: 'Air Purifier with HEPA Filter',
    description: 'Advanced air purifier with true HEPA filter, removes 99.97% of airborne particles. Ideal for homes and offices.',
    price: 12500,
    category: 'appliances',
    subcategory: 'Home Electronics',
    images: ['air-purifier-1.jpg', 'air-purifier-2.jpg'],
    specifications: {
      'Coverage': '400 sq ft',
      'Filter Type': 'True HEPA',
      'Noise Level': '35 dB',
      'Features': 'Air Quality Indicator, Timer'
    },
    stock: 15,
    rating: 4.6,
    reviewCount: 33,
    brand: 'Philips'
  },
  {
    id: '26',
    name: 'Induction Cooktop 2000W',
    description: 'Energy-efficient induction cooktop with touch controls and multiple cooking modes.',
    price: 3500,
    category: 'appliances',
    subcategory: 'Small Appliances',
    images: ['induction-cooktop.jpg'],
    specifications: {
      'Power': '2000W',
      'Cooking Modes': '8 Preset Menus',
      'Features': 'Touch Control, Timer',
      'Warranty': '1 Year'
    },
    stock: 28,
    rating: 4.5,
    reviewCount: 40,
    brand: 'Prestige'
  },
  
  // Plastic Furniture
  {
    id: '27',
    name: 'Plastic Chair Set (4 Pieces)',
    description: 'Durable plastic chairs with ergonomic design. Perfect for indoor and outdoor use.',
    price: 3200,
    category: 'plastic-furniture',
    subcategory: 'Chairs',
    images: ['plastic-chair.jpg'],
    specifications: {
      'Material': 'High-Quality Plastic',
      'Weight Capacity': '120 kg',
      'Color Options': 'White, Blue, Green',
      'Quantity': '4 Pieces'
    },
    stock: 40,
    rating: 4.2,
    reviewCount: 25,
    brand: 'Nilkamal'
  },
  {
    id: '28',
    name: 'Plastic Dining Table',
    description: 'Sturdy plastic dining table with easy-to-clean surface. Ideal for homes and restaurants.',
    price: 5500,
    category: 'plastic-furniture',
    subcategory: 'Tables',
    images: ['plastic-table.jpg'],
    specifications: {
      'Material': 'Premium Plastic',
      'Seating': '4-6 People',
      'Dimensions': '120cm x 75cm',
      'Color': 'White'
    },
    stock: 20,
    rating: 4.3,
    reviewCount: 18,
    brand: 'Supreme'
  },
  {
    id: '29',
    name: 'Plastic Storage Cabinet',
    description: 'Multi-purpose plastic storage cabinet with shelves. Perfect for organizing household items.',
    price: 4800,
    category: 'plastic-furniture',
    subcategory: 'Storage',
    images: ['plastic-cabinet.jpg'],
    specifications: {
      'Material': 'Durable Plastic',
      'Shelves': '4 Adjustable Shelves',
      'Dimensions': '90cm x 45cm x 120cm',
      'Features': 'Lockable Doors'
    },
    stock: 25,
    rating: 4.4,
    reviewCount: 22,
    brand: 'Nilkamal'
  },
  {
    id: '30',
    name: 'Plastic Center Table',
    description: 'Lightweight plastic center table with modern design. Easy to move and maintain.',
    price: 2800,
    category: 'plastic-furniture',
    subcategory: 'Tables',
    images: ['plastic-center-table.jpg'],
    specifications: {
      'Material': 'High-Quality Plastic',
      'Dimensions': '90cm x 60cm x 45cm',
      'Color Options': 'White, Brown',
      'Weight': '5 kg'
    },
    stock: 35,
    rating: 4.1,
    reviewCount: 15,
    brand: 'Supreme'
  },
  
  // Wood Furniture
  {
    id: '31',
    name: 'Solid Wood Bookshelf',
    description: 'Elegant solid wood bookshelf with 5 shelves. Perfect for displaying books and decorative items.',
    price: 18000,
    category: 'wood-furniture',
    subcategory: 'Storage',
    images: ['wood-bookshelf.jpg'],
    specifications: {
      'Material': 'Solid Sheesham Wood',
      'Shelves': '5 Fixed Shelves',
      'Dimensions': '180cm x 90cm x 35cm',
      'Finish': 'Natural Wood Polish'
    },
    stock: 12,
    rating: 4.7,
    reviewCount: 28,
    brand: 'Sri Matha'
  },
  {
    id: '32',
    name: 'Wooden TV Unit',
    description: 'Modern wooden TV unit with storage drawers and cable management. Suitable for TVs up to 55 inches.',
    price: 22000,
    category: 'wood-furniture',
    subcategory: 'Entertainment Units',
    images: ['wood-tv-unit.jpg'],
    specifications: {
      'Material': 'Engineered Wood with Veneer',
      'TV Size': 'Up to 55 inches',
      'Storage': '2 Drawers, 2 Open Shelves',
      'Dimensions': '150cm x 45cm x 55cm'
    },
    stock: 15,
    rating: 4.6,
    reviewCount: 32,
    brand: 'Sri Matha'
  },
  {
    id: '33',
    name: 'Wooden Wardrobe 3 Door',
    description: 'Spacious 3-door wooden wardrobe with mirror and multiple compartments. Perfect for bedrooms.',
    price: 35000,
    category: 'wood-furniture',
    subcategory: 'Wardrobes',
    images: ['wood-wardrobe.jpg'],
    specifications: {
      'Material': 'Engineered Wood',
      'Doors': '3 Doors with Mirror',
      'Compartments': 'Hanging Space, Shelves, Drawers',
      'Dimensions': '180cm x 60cm x 200cm'
    },
    stock: 8,
    rating: 4.8,
    reviewCount: 35,
    brand: 'Sri Matha'
  },
  {
    id: '34',
    name: 'Wooden Study Table',
    description: 'Compact wooden study table with drawers and bookshelf. Ideal for students and home offices.',
    price: 12000,
    category: 'wood-furniture',
    subcategory: 'Tables',
    images: ['wood-study-table.jpg'],
    specifications: {
      'Material': 'Engineered Wood',
      'Storage': '2 Drawers, Side Bookshelf',
      'Dimensions': '120cm x 60cm x 75cm',
      'Color': 'Walnut Brown'
    },
    stock: 18,
    rating: 4.5,
    reviewCount: 24,
    brand: 'Sri Matha'
  },
  {
    id: '35',
    name: 'Wooden Rocking Chair',
    description: 'Traditional wooden rocking chair with comfortable seating. Perfect for relaxation.',
    price: 8500,
    category: 'wood-furniture',
    subcategory: 'Chairs',
    images: ['wood-rocking-chair.jpg'],
    specifications: {
      'Material': 'Solid Teak Wood',
      'Features': 'Ergonomic Design, Smooth Rocking',
      'Dimensions': '65cm x 80cm x 95cm',
      'Finish': 'Natural Polish'
    },
    stock: 10,
    rating: 4.6,
    reviewCount: 19,
    brand: 'Sri Matha'
  }
];

export const reviews: Review[] = [
  {
    id: 'r1',
    productId: '1',
    userName: 'Rajesh Kumar',
    rating: 5,
    comment: 'Excellent quality sofa! Very comfortable and looks amazing in my living room.',
    date: '2024-11-15'
  },
  {
    id: 'r2',
    productId: '1',
    userName: 'Priya Sharma',
    rating: 4,
    comment: 'Good product, delivery was on time. Slightly expensive but worth it.',
    date: '2024-11-10'
  },
  {
    id: 'r3',
    productId: '2',
    userName: 'Anil Patel',
    rating: 5,
    comment: 'Best bed with storage! The hydraulic system works smoothly.',
    date: '2024-11-20'
  },
  {
    id: 'r4',
    productId: '4',
    userName: 'Sunita Reddy',
    rating: 5,
    comment: 'Duroflex mattress is amazing! My back pain has reduced significantly.',
    date: '2024-11-18'
  },
  {
    id: 'r5',
    productId: '7',
    userName: 'Vikram Singh',
    rating: 4,
    comment: 'Very comfortable office chair. Good lumbar support for long working hours.',
    date: '2024-11-12'
  }
];

export const customerTestimonials = [
  {
    id: 't1',
    name: 'Ramesh Patro',
    location: 'Paralakhemundi',
    rating: 5,
    comment: 'Sri Matha Furniture has been our family\'s trusted choice for over 10 years. The quality and service are exceptional!',
    date: '2024-12-10'
  },
  {
    id: 't2',
    name: 'Lakshmi Devi',
    location: 'Berhampur',
    rating: 5,
    comment: 'Bought a complete bedroom set from Sri Matha. The furniture quality is outstanding and the prices are very reasonable.',
    date: '2024-12-08'
  },
  {
    id: 't3',
    name: 'Suresh Naidu',
    location: 'Visakhapatnam',
    rating: 5,
    comment: 'Excellent customer service! They helped me choose the perfect office furniture for my new business. Highly recommended!',
    date: '2024-12-05'
  },
  {
    id: 't4',
    name: 'Kavita Mishra',
    location: 'Rayagada',
    rating: 5,
    comment: 'The Duroflex mattress I purchased has improved my sleep quality tremendously. Thank you Sri Matha Furniture!',
    date: '2024-12-01'
  },
  {
    id: 't5',
    name: 'Prakash Rao',
    location: 'Gunupur',
    rating: 5,
    comment: 'Best furniture store in the region! Great variety, quality products, and honest pricing. Been a customer for 15 years.',
    date: '2024-11-28'
  },
  {
    id: 't6',
    name: 'Anjali Behera',
    location: 'Paralakhemundi',
    rating: 5,
    comment: 'Recently furnished my entire home with Sri Matha. The staff was very helpful and the delivery was prompt. Very satisfied!',
    date: '2024-11-25'
  }
];
