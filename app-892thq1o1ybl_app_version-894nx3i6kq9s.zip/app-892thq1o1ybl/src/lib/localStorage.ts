import type { CartItem, Order, Review } from '@/types/types';

const CART_KEY = 'sri_matha_cart';
const ORDERS_KEY = 'sri_matha_orders';
const REVIEWS_KEY = 'sri_matha_reviews';

export const cartStorage = {
  get: (): CartItem[] => {
    try {
      const data = localStorage.getItem(CART_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  set: (cart: CartItem[]): void => {
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch (error) {
      console.error('Failed to save cart:', error);
    }
  },

  add: (item: CartItem): void => {
    const cart = cartStorage.get();
    const existingIndex = cart.findIndex(i => i.product.id === item.product.id);
    
    if (existingIndex >= 0) {
      cart[existingIndex].quantity += item.quantity;
    } else {
      cart.push(item);
    }
    
    cartStorage.set(cart);
  },

  update: (productId: string, quantity: number): void => {
    const cart = cartStorage.get();
    const index = cart.findIndex(i => i.product.id === productId);
    
    if (index >= 0) {
      if (quantity <= 0) {
        cart.splice(index, 1);
      } else {
        cart[index].quantity = quantity;
      }
      cartStorage.set(cart);
    }
  },

  remove: (productId: string): void => {
    const cart = cartStorage.get();
    const filtered = cart.filter(i => i.product.id !== productId);
    cartStorage.set(filtered);
  },

  clear: (): void => {
    localStorage.removeItem(CART_KEY);
  },

  getTotal: (): number => {
    const cart = cartStorage.get();
    return cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  },

  getItemCount: (): number => {
    const cart = cartStorage.get();
    return cart.reduce((count, item) => count + item.quantity, 0);
  }
};

export const orderStorage = {
  get: (): Order[] => {
    try {
      const data = localStorage.getItem(ORDERS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  add: (order: Order): void => {
    const orders = orderStorage.get();
    orders.unshift(order);
    try {
      localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
    } catch (error) {
      console.error('Failed to save order:', error);
    }
  },

  getById: (orderId: string): Order | undefined => {
    const orders = orderStorage.get();
    return orders.find(o => o.id === orderId);
  }
};

export const reviewStorage = {
  get: (): Review[] => {
    try {
      const data = localStorage.getItem(REVIEWS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  add: (review: Review): void => {
    const reviews = reviewStorage.get();
    reviews.push(review);
    try {
      localStorage.setItem(REVIEWS_KEY, JSON.stringify(reviews));
    } catch (error) {
      console.error('Failed to save review:', error);
    }
  },

  getByProductId: (productId: string): Review[] => {
    const reviews = reviewStorage.get();
    return reviews.filter(r => r.productId === productId);
  }
};
