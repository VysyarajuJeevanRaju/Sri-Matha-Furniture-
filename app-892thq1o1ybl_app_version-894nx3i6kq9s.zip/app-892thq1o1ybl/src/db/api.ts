import { supabase } from './supabase';
import type {
  Product,
  Review,
  Testimonial,
  CartItem,
  Order,
  DbProduct,
  DbReview,
  DbTestimonial,
  DbCartItem,
  DbOrder,
  DbOrderItem,
  DbContactSubmission
} from '@/types/types';

// Helper function to get or create user UUID
export const getUserUUID = (): string => {
  let userUUID = localStorage.getItem('user_uuid');
  if (!userUUID) {
    userUUID = crypto.randomUUID();
    localStorage.setItem('user_uuid', userUUID);
  }
  return userUUID;
};

// Helper function to convert DbProduct to Product
const dbProductToProduct = (dbProduct: DbProduct): Product => ({
  id: dbProduct.id,
  name: dbProduct.name,
  description: dbProduct.description || '',
  price: Number(dbProduct.price),
  category: dbProduct.category as Product['category'],
  subcategory: dbProduct.subcategory || undefined,
  images: dbProduct.images || [],
  specifications: dbProduct.specifications || {},
  stock: dbProduct.stock,
  rating: Number(dbProduct.rating),
  reviewCount: dbProduct.review_count,
  brand: dbProduct.brand || undefined
});

// Helper function to convert DbReview to Review
const dbReviewToReview = (dbReview: DbReview): Review => ({
  id: dbReview.id,
  productId: dbReview.product_id,
  userName: dbReview.user_name,
  rating: dbReview.rating,
  comment: dbReview.comment || '',
  date: dbReview.created_at
});

// Helper function to convert DbTestimonial to Testimonial
const dbTestimonialToTestimonial = (dbTestimonial: DbTestimonial): Testimonial => ({
  id: dbTestimonial.id,
  name: dbTestimonial.name,
  location: dbTestimonial.location || '',
  rating: dbTestimonial.rating,
  comment: dbTestimonial.comment,
  date: dbTestimonial.created_at
});

// Products API
export const getProducts = async (filters?: {
  category?: string;
  search?: string;
  sortBy?: string;
}): Promise<Product[]> => {
  let query = supabase.from('products').select('*').order('created_at', { ascending: false });

  if (filters?.category && filters.category !== 'all') {
    query = query.eq('category', filters.category);
  }

  if (filters?.search) {
    query = query.or(`name.ilike.%${filters.search}%,description.ilike.%${filters.search}%`);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching products:', error);
    return [];
  }

  return Array.isArray(data) ? data.map(dbProductToProduct) : [];
};

export const getProductById = async (id: string): Promise<Product | null> => {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error) {
    console.error('Error fetching product:', error);
    return null;
  }

  return data ? dbProductToProduct(data as DbProduct) : null;
};

// Reviews API
export const getReviewsByProductId = async (productId: string): Promise<Review[]> => {
  const { data, error } = await supabase
    .from('reviews')
    .select('*')
    .eq('product_id', productId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching reviews:', error);
    return [];
  }

  return Array.isArray(data) ? data.map(dbReviewToReview) : [];
};

export const createReview = async (review: {
  productId: string;
  userName: string;
  rating: number;
  comment: string;
}): Promise<Review | null> => {
  const { data, error } = await supabase
    .from('reviews')
    .insert({
      product_id: review.productId,
      user_name: review.userName,
      rating: review.rating,
      comment: review.comment
    })
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating review:', error);
    return null;
  }

  return data ? dbReviewToReview(data as DbReview) : null;
};

// Testimonials API
export const getTestimonials = async (): Promise<Testimonial[]> => {
  const { data, error } = await supabase
    .from('testimonials')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching testimonials:', error);
    return [];
  }

  return Array.isArray(data) ? data.map(dbTestimonialToTestimonial) : [];
};

// Cart API
export const getCartItems = async (): Promise<CartItem[]> => {
  const userUUID = getUserUUID();

  const { data, error } = await supabase
    .from('cart_items')
    .select(`
      *,
      products (*)
    `)
    .eq('user_uuid', userUUID)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching cart items:', error);
    return [];
  }

  if (!Array.isArray(data)) return [];

  return data.map((item: any) => ({
    product: dbProductToProduct(item.products as DbProduct),
    quantity: item.quantity
  }));
};

export const addToCart = async (productId: string, quantity: number = 1): Promise<boolean> => {
  const userUUID = getUserUUID();

  // Check if item already exists in cart
  const { data: existing } = await supabase
    .from('cart_items')
    .select('*')
    .eq('user_uuid', userUUID)
    .eq('product_id', productId)
    .maybeSingle();

  if (existing) {
    // Update quantity
    const { error } = await supabase
      .from('cart_items')
      .update({ quantity: (existing as DbCartItem).quantity + quantity })
      .eq('id', (existing as DbCartItem).id);

    if (error) {
      console.error('Error updating cart item:', error);
      return false;
    }
  } else {
    // Insert new item
    const { error } = await supabase
      .from('cart_items')
      .insert({
        user_uuid: userUUID,
        product_id: productId,
        quantity
      });

    if (error) {
      console.error('Error adding to cart:', error);
      return false;
    }
  }

  return true;
};

export const updateCartItemQuantity = async (productId: string, quantity: number): Promise<boolean> => {
  const userUUID = getUserUUID();

  if (quantity <= 0) {
    return removeFromCart(productId);
  }

  const { error } = await supabase
    .from('cart_items')
    .update({ quantity })
    .eq('user_uuid', userUUID)
    .eq('product_id', productId);

  if (error) {
    console.error('Error updating cart item quantity:', error);
    return false;
  }

  return true;
};

export const removeFromCart = async (productId: string): Promise<boolean> => {
  const userUUID = getUserUUID();

  const { error } = await supabase
    .from('cart_items')
    .delete()
    .eq('user_uuid', userUUID)
    .eq('product_id', productId);

  if (error) {
    console.error('Error removing from cart:', error);
    return false;
  }

  return true;
};

export const clearCart = async (): Promise<boolean> => {
  const userUUID = getUserUUID();

  const { error } = await supabase
    .from('cart_items')
    .delete()
    .eq('user_uuid', userUUID);

  if (error) {
    console.error('Error clearing cart:', error);
    return false;
  }

  return true;
};

// Orders API
export const createOrder = async (orderData: {
  items: CartItem[];
  totalAmount: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: string;
}): Promise<string | null> => {
  const userUUID = getUserUUID();

  // Create order
  const { data: order, error: orderError } = await supabase
    .from('orders')
    .insert({
      user_uuid: userUUID,
      total_amount: orderData.totalAmount,
      status: 'pending',
      customer_name: orderData.customerName,
      customer_email: orderData.customerEmail,
      customer_phone: orderData.customerPhone,
      shipping_address: orderData.shippingAddress
    })
    .select()
    .maybeSingle();

  if (orderError || !order) {
    console.error('Error creating order:', orderError);
    return null;
  }

  // Create order items
  const orderItems = orderData.items.map(item => ({
    order_id: (order as DbOrder).id,
    product_id: item.product.id,
    product_name: item.product.name,
    product_price: item.product.price,
    quantity: item.quantity,
    subtotal: item.product.price * item.quantity
  }));

  const { error: itemsError } = await supabase
    .from('order_items')
    .insert(orderItems);

  if (itemsError) {
    console.error('Error creating order items:', itemsError);
    return null;
  }

  // Clear cart after successful order
  await clearCart();

  return (order as DbOrder).id;
};

export const getOrderById = async (orderId: string): Promise<Order | null> => {
  const { data: order, error: orderError } = await supabase
    .from('orders')
    .select('*')
    .eq('id', orderId)
    .maybeSingle();

  if (orderError || !order) {
    console.error('Error fetching order:', orderError);
    return null;
  }

  const { data: items, error: itemsError } = await supabase
    .from('order_items')
    .select(`
      *,
      products (*)
    `)
    .eq('order_id', orderId)
    .order('id', { ascending: true });

  if (itemsError) {
    console.error('Error fetching order items:', itemsError);
    return null;
  }

  const dbOrder = order as DbOrder;
  const cartItems: CartItem[] = Array.isArray(items) ? items.map((item: any) => ({
    product: dbProductToProduct(item.products as DbProduct),
    quantity: item.quantity
  })) : [];

  return {
    id: dbOrder.id,
    items: cartItems,
    totalAmount: Number(dbOrder.total_amount),
    status: dbOrder.status as Order['status'],
    date: dbOrder.created_at,
    customerName: dbOrder.customer_name || undefined,
    customerEmail: dbOrder.customer_email || undefined,
    customerPhone: dbOrder.customer_phone || undefined,
    shippingAddress: dbOrder.shipping_address || undefined
  };
};

// Contact Form API
export const submitContactForm = async (formData: {
  name: string;
  email: string;
  phone?: string;
  message: string;
}): Promise<boolean> => {
  const { error } = await supabase
    .from('contact_submissions')
    .insert({
      name: formData.name,
      email: formData.email,
      phone: formData.phone || null,
      message: formData.message
    });

  if (error) {
    console.error('Error submitting contact form:', error);
    return false;
  }

  return true;
};
