import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

// Create a mock Supabase client for when credentials are not available
const createMockClient = (): SupabaseClient => {
  const mockResponse = {
    data: null,
    error: { message: 'Supabase not configured. Please add credentials to .env.local' }
  };

  return {
    from: () => ({
      select: () => Promise.resolve(mockResponse),
      insert: () => Promise.resolve(mockResponse),
      update: () => Promise.resolve(mockResponse),
      delete: () => Promise.resolve(mockResponse),
      eq: () => ({ maybeSingle: () => Promise.resolve(mockResponse) }),
      maybeSingle: () => Promise.resolve(mockResponse),
      order: () => ({ limit: () => Promise.resolve(mockResponse) })
    }),
    storage: {
      from: () => ({
        upload: () => Promise.resolve(mockResponse),
        download: () => Promise.resolve(mockResponse)
      })
    },
    functions: {
      invoke: () => Promise.resolve(mockResponse)
    }
  } as any;
};

// Only create real client if credentials are provided
export const supabase = (supabaseUrl && supabaseAnonKey) 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : (() => {
      console.warn('⚠️ Supabase credentials not found. Database features will be disabled.');
      console.warn('📝 To enable database features, add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to .env.local');
      return createMockClient();
    })();
