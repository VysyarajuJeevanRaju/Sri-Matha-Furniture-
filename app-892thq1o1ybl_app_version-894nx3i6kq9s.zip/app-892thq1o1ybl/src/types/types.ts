export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: ProductCategory;
  subcategory?: string;
  images: string[];
  specifications?: Record<string, string>;
  stock: number;
  rating: number;
  reviewCount: number;
  brand?: string;
}

export type ProductCategory = 'furniture' | 'appliances' | 'office' | 'mattress' | 'steel-almarah' | 'plastic-furniture' | 'wood-furniture';

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Review {
  id: string;
  productId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  totalAmount: number;
  status: 'pending' | 'completed' | 'cancelled';
  date: string;
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  shippingAddress?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
}

// Database types (matching SQL schema exactly)
export interface DbProduct {
  id: string;
  name: string;
  description: string | null;
  price: number;
  category: string;
  subcategory: string | null;
  images: string[];
  specifications: Record<string, string>;
  stock: number;
  rating: number;
  review_count: number;
  brand: string | null;
  created_at: string;
  updated_at: string;
}

export interface DbReview {
  id: string;
  product_id: string;
  user_name: string;
  rating: number;
  comment: string | null;
  created_at: string;
}

export interface DbTestimonial {
  id: string;
  name: string;
  location: string | null;
  rating: number;
  comment: string;
  created_at: string;
}

export interface DbCartItem {
  id: string;
  user_uuid: string;
  product_id: string;
  quantity: number;
  created_at: string;
  updated_at: string;
}

export interface DbOrder {
  id: string;
  user_uuid: string;
  total_amount: number;
  status: string;
  customer_name: string | null;
  customer_email: string | null;
  customer_phone: string | null;
  shipping_address: string | null;
  created_at: string;
  updated_at: string;
}

export interface DbOrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  product_price: number;
  quantity: number;
  subtotal: number;
}

export interface DbContactSubmission {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  message: string;
  created_at: string;
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  rating: number;
  comment: string;
  date: string;
}
